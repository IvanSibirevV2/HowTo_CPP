#pragma option push -b -a8 -pc -A- /*P_O_Push*/
/*****************************************************************************/
/* Now a stub file to allow back compatibility, real file is winmgt.h        */
/*****************************************************************************/
#include <winmgt.h>


#pragma option pop /*P_O_Pop*/
