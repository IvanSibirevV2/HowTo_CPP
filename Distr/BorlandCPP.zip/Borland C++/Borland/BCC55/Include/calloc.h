/*  calloc.h

    Standard C header file wrapper for alloc.h
*/

/*
 *      C/C++ Run Time Library - Version 10.0
 *
 *      Copyright (c) 1997, 2000 by Inprise Corporation
 *      All Rights Reserved.
 *
 */

/* $Revision:   9.0  $ */

#define  __USING_CNAME__
#include <alloc.h>
#undef   __USING_CNAME__