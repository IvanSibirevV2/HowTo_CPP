#pragma option push -b -a8 -pc -A- /*P_O_Push*/
#ifndef RC_INVOKED
#pragma message("WARNING: your code should #include srv.h instead of srvconst.h")
#endif /* !RC_INVOKED */

#include "srv.h"
#pragma option pop /*P_O_Pop*/
