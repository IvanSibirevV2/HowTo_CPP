#pragma option push -b -a8 -pc -A- /*P_O_Push*/

/*****************************************************************************/
/* Stub file, real code is in WINLUA.H                                       */
/*****************************************************************************/
#include <winlua.h>
#pragma option pop /*P_O_Pop*/
