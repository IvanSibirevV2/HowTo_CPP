//+-------------------------------------------------------------------------
//
//  Copyright (C) Microsoft Corporation, 1991 - 1996.
//
//  Contents:  Scheduling Agent interface error definitions.
//
//--------------------------------------------------------------------------
#ifndef _MSTERR_H_
#pragma option push -b -a8 -pc -A- /*P_O_Push*/
#define _MSTERR_H_
#include "winerror.h"
// Task Scheduler error codes have been moved to winerror.h
#pragma option pop /*P_O_Pop*/
#endif // _MSTERR_H_
