#pragma option push -b -a8 -pc -A- /*P_O_Push*/
//  Copyright (C) 1995-1999 Microsoft Corporation.  All rights reserved.
#include "comsvcs.h"
#pragma option pop /*P_O_Pop*/
